import java.util.List;

public class WithFlavor extends CoffeeDecorator {
    private Syrup flavor;

    public WithFlavor (Coffee c, Syrup s) {
        super(c);
        this.flavor = s;
    }

    @Override
    public double getCost() {
        return super.getCost() + 0.35;
    }

    @Override
    public List<String> getIngredients() {
        return null;
    }

    @Override
    public String printCoffee() {
        return super.printCoffee() + " with " + this.flavor;
    }
}
