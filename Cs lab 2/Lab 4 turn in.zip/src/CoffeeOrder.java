import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;


public class CoffeeOrder {
    private List<Coffee> coffees;
    private LocalDateTime orderDate;
    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd KK:mma");

    public CoffeeOrder() {
        coffees = new ArrayList<Coffee>();
        orderDate = LocalDateTime.now();
    }

    public void addCoffee(Coffee c) {
        coffees.add(c);
    }

    public List<Coffee> getCoffees() {
        return coffees;
    }

    public LocalDateTime getOrderDate() {
        return orderDate;
    }

    public double getTotal() {
        double total = 0;
        for (Coffee count : coffees) {
            total += count.getCost();
        }
        return total;
    }

    public String printOrder() {
        StringBuilder out = new StringBuilder("ORDER RECEIPT\n" + "Timestamp: " + getOrderDate().format(formatter)
                + "\n");
        int i = 1;
        for (Coffee count : coffees) {
            out.append("Item " + i + ": " + count.printCoffee() + " - " + String.format("%.2f", count.getCost())
                    + "\n");
            i++;
        }
        out.append("TOTAL = " + getTotal());
        return out.toString();
    }
}
