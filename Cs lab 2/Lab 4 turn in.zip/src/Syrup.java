public enum Syrup {
    Caramel,
    Mocha,
    Vanilla
}
