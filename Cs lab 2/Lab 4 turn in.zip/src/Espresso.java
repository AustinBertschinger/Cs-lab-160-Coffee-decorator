import java.util.List;

public class Espresso implements Coffee {
    public Espresso() {
    }
    @Override
    public double getCost() {
        return 1.75;
    }
    @Override
    public List<String> getIngredients() {
        return null;
    }
    @Override
    public String printCoffee() {
        return "An espresso";
    }

}
