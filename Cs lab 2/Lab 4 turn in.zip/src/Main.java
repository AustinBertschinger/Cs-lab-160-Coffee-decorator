
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Main {
    private static Map<String, Integer> inventory = new TreeMap<String, Integer>();
    private static List<CoffeeOrder> orders = new ArrayList<CoffeeOrder>();
    private static String logFile = "OrderLog.txt";
    private static String inventoryFile = "";

    private static CoffeeOrder buildOrder() {
        Scanner userIn = new Scanner(System.in);
        CoffeeOrder order = new CoffeeOrder();
        orders.add(order);
        String input = "placeholder";
        while(!input.equals("done")) {
            System.out.println("To add a coffee to your order, type in 'add'. To finalize your order, type in 'done'");
            input = userIn.nextLine();
            if (input.equals("add")) {
                System.out.println("Would you like an 'espresso' or a 'black coffee'?");
                input = userIn.nextLine();
                if (input.equals("espresso")) {
                    Coffee c = new Espresso();
                    System.out.println("Would you like to add any decorators?");
                    System.out.println("Options include, 'hot water', 'milk', 'sugar', 'whipped cream', and " +
                            "your choice of flavor between 'caramel', 'mocha', and 'vanilla'");
                    System.out.println("If you are done adding decorators, type in 'finish'");
                    input = userIn.nextLine();
                    while (!input.equals("finish")) {
                        switch (input) {
                            case "hot water":
                                c = new WithHotWater(c);
                                System.out.println("Added hot water.");
                                input = userIn.nextLine();
                                break;
                            case "milk":
                                c = new WithMilk(c);
                                System.out.println("Added milk.");
                                input = userIn.nextLine();
                                break;
                            case "sugar":
                                c = new WithSugar(c);
                                System.out.println("Added sugar.");
                                input = userIn.nextLine();
                                break;
                            case "whipped cream":
                                c = new WithWhippedCream(c);
                                System.out.println("Added whipped cream.");
                                input = userIn.nextLine();
                                break;
                            case "caramel":
                                c = new WithFlavor(c, Syrup.Caramel);
                                System.out.println("Added caramel.");
                                input = userIn.nextLine();
                                break;
                            case "vanilla":
                                c = new WithFlavor(c, Syrup.Vanilla);
                                System.out.println("Added vanilla.");
                                input = userIn.nextLine();
                                break;
                            case "mocha":
                                c = new WithFlavor(c, Syrup.Mocha);
                                System.out.println("Added mocha.");
                                input = userIn.nextLine();
                                break;
                        }
                    }
                    if (input.equals("finish")) {
                        order.addCoffee(c);
                        System.out.println("Added to order!");
                        input = userIn.nextLine();
                    }
                }
                else if (input.equals("black coffee")) {
                    Coffee c = new BlackCoffee();
                    System.out.println("Would you like to add any decorators?");
                    System.out.println("Options include, 'hot water', 'milk', 'sugar', 'whipped cream', and " +
                            "your choice of flavor between 'caramel', 'mocha', and 'vanilla'");
                    System.out.println("If you are done adding decorators, type in 'finish'");
                    input = userIn.nextLine();
                    while (!input.equals("finish")) {
                        switch (input) {
                            case "hot water":
                                c = new WithHotWater(c);
                                System.out.println("Added hot water.");
                                input = userIn.nextLine();
                                break;
                            case "milk":
                                c = new WithMilk(c);
                                System.out.println("Added milk.");
                                input = userIn.nextLine();
                                break;
                            case "sugar":
                                c = new WithSugar(c);
                                System.out.println("Added sugar.");
                                input = userIn.nextLine();
                                break;
                            case "whipped cream":
                                c = new WithWhippedCream(c);
                                System.out.println("Added whipped cream.");
                                input = userIn.nextLine();
                                break;
                            case "caramel":
                                c = new WithFlavor(c, Syrup.Caramel);
                                System.out.println("Added caramel.");
                                input = userIn.nextLine();
                                break;
                            case "vanilla":
                                c = new WithFlavor(c, Syrup.Vanilla);
                                System.out.println("Added vanilla.");
                                input = userIn.nextLine();
                                break;
                            case "mocha":
                                c = new WithFlavor(c, Syrup.Mocha);
                                System.out.println("Added mocha.");
                                input = userIn.nextLine();
                                break;
                        }
                    }
                    if (input.equals("finish")) {
                        order.addCoffee(c);
                        System.out.println("Added to order!");
                        input = userIn.nextLine();
                    }
                }
            }
        }
        return order;
    }

    public static void main(String[] args) {
        Scanner scnr = new Scanner(System.in);
        String input = "placeholder";
        do {
            System.out.println("Hello! Would you like to create a new coffee order? If so, enter 'yes', otherwise, " +
                    "enter 'no'.");
            input = scnr.nextLine();
            if (input.equals("yes")) {
                System.out.println(buildOrder().printOrder());

            }
        } while (!input.equals("no"));
        writeOrderLog(logFile);
        System.out.println("Thank your for choosing us as your coffee shop of the day!");

    }
    private static Map<String, Integer> readInventory(String filePath) {
        return null;
    }
    private static void writeInventory(String filePath) {}
    private static List<CoffeeOrder> readOrderLog(String filePath) {
        return null;
    }
    private static void writeOrderLog(String filePath) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (CoffeeOrder count : orders) {
                bw.write(count.printOrder());
                bw.newLine();
            }
            orders.clear();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }
    private static boolean isInInventory(String i) {
        return false;
    }
    private static void updateOrderLog() {}
}
