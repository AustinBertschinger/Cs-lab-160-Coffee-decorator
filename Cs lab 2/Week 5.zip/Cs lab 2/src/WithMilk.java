import java.util.List;

public class WithMilk extends CoffeeDecorator {

    public WithMilk (Coffee c) {
        super(c);
    }

    @Override
    public double getCost() {
        return super.getCost() + 0.55;
    }

    @Override
    public List<String> getIngredients() {
        super.ingredients.add("Milk");
        return super.ingredients;
    }

    @Override
    public String printCoffee() {
        return super.printCoffee() + " with milk";
    }
}
