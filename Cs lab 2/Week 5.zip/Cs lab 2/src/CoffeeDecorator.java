import java.util.ArrayList;
import java.util.List;

public abstract class CoffeeDecorator implements Coffee {
    private Coffee coffee;
    List<String> ingredients;


    public CoffeeDecorator (Coffee c) {
        this.coffee = c;
        this.ingredients = coffee.getIngredients();
    }

    public double getCost() {
        return coffee.getCost();
    }

    public List<String> getIngredients() {
        return ingredients;
    }
    public String printCoffee() {
        return coffee.printCoffee();
    }


}
